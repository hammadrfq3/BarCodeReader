package com.companyname.ppsc.Controller

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.companyname.ppsc.R

class BachelorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bachelor)
    }
}